package com.Zaryabkhan;

public class Main {
    public static void main(String[] args) {com.Zaryab.bfs.BFSRouting.launchApp(args); // <- Must match exact class name
    }
}