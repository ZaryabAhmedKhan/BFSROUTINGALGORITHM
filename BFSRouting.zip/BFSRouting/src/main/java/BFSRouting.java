package com.Zaryab.bfs;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.geometry.Insets;

import java.util.List;

public class BFSRouting extends Application {
    Graph graphManager = new Graph();
    Pane canvas = new Pane();
    TextArea log = new TextArea();
    TextField nodeField = new TextField(), fromField = new TextField(), toField = new TextField();
    ComboBox<String> sourceBox = new ComboBox<>(), destBox = new ComboBox<>();
    final int RADIUS = 20;

    public static void launchApp(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        VBox controls = new VBox(10,
                new Label("Node:"), nodeField, btn("Add Node", e -> addNode()),
                new Label("From:"), fromField, new Label("To:"), toField,
                btn("Add Edge", e -> addEdge()),
                new Label("Source:"), sourceBox, new Label("Destination:"), destBox,
                btn("Find Path", e -> findPath()), btn("Generate Random Graph", e -> genRandomGraph())
        );
        controls.setPadding(new Insets(10));
        controls.setPrefWidth(250);

        canvas.setPrefSize(500, 300);
        canvas.setStyle("-fx-background-color: black;");
        log.setPrefHeight(100);
        log.setEditable(false);

        BorderPane root = new BorderPane(canvas, null, null, log, controls);
        stage.setScene(new Scene(root, 900, 600));
        stage.setTitle("BFS Routing Algorithm");
        stage.show();
        log("Simulator ready. Add nodes and edges.");
    }

    void addNode() {
        String name = nodeField.getText().trim().toUpperCase();
        if (graphManager.addNode(name)) {
            sourceBox.getItems().add(name);
            destBox.getItems().add(name);
            draw();
            log("Node added: " + name);
        } else {
            log("Invalid or duplicate node.");
        }
        nodeField.clear();
    }

    void addEdge() {
        String from = fromField.getText().trim().toUpperCase();
        String to = toField.getText().trim().toUpperCase();
        if (graphManager.addEdge(from, to)) {
            draw();
            log("Edge added: " + from + " - " + to);
        } else {
            log("Invalid nodes for edge.");
        }
        fromField.clear();
        toField.clear();
    }

    void findPath() {
        String src = sourceBox.getValue();
        String dst = destBox.getValue();
        List<String> path = graphManager.bfsPath(src, dst);
        draw();
        if (path == null) {
            log("No path found.");
        } else {
            for (int i = 0; i < path.size() - 1; i++) {
                drawEdge(path.get(i), path.get(i + 1), Color.RED, 3);
            }
            log("Path found: " + path);
        }
    }

    void genRandomGraph() {
        graphManager.generateRandomGraph();
        sourceBox.getItems().setAll(graphManager.getAllNodes());
        destBox.getItems().setAll(graphManager.getAllNodes());
        draw();
        log("Random graph generated.");
    }

    void draw() {
        canvas.getChildren().clear();
        for (String from : graphManager.getAllNodes()) {
            for (String to : graphManager.getNeighbors(from)) {
                if (from.compareTo(to) < 0) {
                    drawEdge(from, to, Color.WHITE, 1);
                }
            }
        }
        for (String node : graphManager.getAllNodes()) {
            double[] pos = graphManager.getPosition(node);
            Circle circle = new Circle(pos[0], pos[1], RADIUS, Color.WHITE);
            circle.setStroke(Color.BLACK);
            Text text = new Text(pos[0] - 5, pos[1] + 5, node);
            canvas.getChildren().addAll(circle, text);
        }
    }

    void drawEdge(String from, String to, Color color, int width) {
        double[] p1 = graphManager.getPosition(from), p2 = graphManager.getPosition(to);
        Line line = new Line(p1[0], p1[1], p2[0], p2[1]);
        line.setStroke(color);
        line.setStrokeWidth(width);
        canvas.getChildren().add(line);
    }

    void log(String msg) {
        log.appendText(msg + "\n");
    }

    Button btn(String label, javafx.event.EventHandler<javafx.event.ActionEvent> handler) {
        Button b = new Button(label);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setOnAction(handler);
        return b;
    }
}
